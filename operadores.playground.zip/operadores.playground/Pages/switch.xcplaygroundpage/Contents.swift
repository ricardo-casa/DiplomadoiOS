
/* Deben ser exhaustivos, evaluan en una operacion a la vez*/
var time:Int = 5

/// este es un ejemplo de caso compuesto
switch time {
case 0...6, 19...23:
    print("todo cool perro pero dentro de un switch")
    break
    
case 7...12:
    print("usa un bloqueador durante el dia perro! pero dentro de un switch")
    break

default:
    break
}


/// comparacion de tuplas
/// el underscore es servira para omitir campos en las tuplas que hemos
/// #fallthrough sirve para continuar los demas casos en un switch lo que permite que despues de validar
///  #caigamos en el los demas casos

let color = (54,255,3)

switch color {
case (_,_,255):
    print("max blue")
    
case let (r, 255, b) where r < 55 : /// #con value binding y clausula where para especificar aun mas los casos del value binding
    print("\(r) \(b) max red")

default:
    break
}


// MARK: EJERCICIO DE COORDENADAS

let coord : ( Double, Double ) = (1.5, 5.0)

switch (coord) {
    case let (x,y) where x == 0 || y == 0: /// 0, 0
        print("en el centro")

    case let (x,y) where 0...5 ~= x && 0...5 ~= y : /// x, y
        print("primer cuadrante")

    case let (x,y) where -5..<0 ~= x && 0...5 ~= y : /// -x, y
        print("segundo cuadrante")
        
    case let (x,y) where -5..<0 ~= x && -5..<0 ~= y : /// -x, -y
        print("tercer cuadrante")

    case let (x,y) where 0...5 ~= x && -5..<0 ~= y : /// x, -y
        print("cuarto cuadrante")

    default:
        print("out of range")
}

let animal = "dog"

guard animal == "dog" else {
    fatalError("cocos")
}
print (animal)

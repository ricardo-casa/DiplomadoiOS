//: [Previous](@previous)

import Foundation

var greeting = "Hello, playground"


let intervals = stride(from: 0, to: 20, by: 5)


for interval in intervals {
    for i in 0...interval {
        print(i)
    
    }
}




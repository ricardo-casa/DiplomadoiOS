/// se les conoce como tipos de primera clase siendo valores
/// valores computados
/// protocolos asociados
/// con uppercamel case y en singular
///


import Foundation

/// al momento todos los inicializadores de un enum, se definen como opcionales
enum Pet : String { /// el :String se refiere al raw value ya cada uno de los cases los define con ese tipo de dato
    case dog = "🐶"
    case cat = "🐼"
    case parrot = "🦜"
}

/// en este caso no se sabe que es el inicializador y buscara
/// si en los casos que se definieron
let myPet = Pet(rawValue: "🐶")

/// en este caso por otro lado nosotros si conocemos que el inicializador
/// que se requiere
let myParrot : Pet = .parrot

print(type(of: myPet))
print(myPet!.rawValue)


switch myPet {
case .dog:
    print(myPet?.rawValue ?? "🐶")
    
default:
        break
}

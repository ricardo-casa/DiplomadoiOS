import Foundation

var cellphone: String = "5543195386"
var landLine: String? = nil

print(landLine ?? "no tengo telefono")

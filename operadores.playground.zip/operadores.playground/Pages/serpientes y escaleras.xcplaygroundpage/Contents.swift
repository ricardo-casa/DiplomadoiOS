//: [Previous](@previous)

import Foundation

let board: [ Int ] = Array(0 ... 24)

var dice: Int = Int.random(in: 1 ... 6)
var playDice: Bool = true

func snakesLaddersController( currentPosition : Int ) -> Int {
    var newPosition : Int = currentPosition
    
    switch currentPosition {
    case 2: newPosition += 5
    
    case 5: newPosition += 11
    
    case 8: newPosition += 9
    
    case 9: newPosition += 5
        
    case 13: newPosition -= 10
    
    case 18: newPosition -= 12
        
    case 21: newPosition -= 11
        
    case 23: newPosition -= 8
        
    default: break
        
    }
    return newPosition
}

while (playDice) {
    
    var currentPosition : Int = dice
    print(currentPosition)
    
    currentPosition = snakesLaddersController(currentPosition: currentPosition)
    print(currentPosition)
    playDice = false
    
}

//: [Next](@next)
